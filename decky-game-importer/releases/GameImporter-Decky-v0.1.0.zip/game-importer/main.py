import base64
import json
import os
import re
import shlex
import stat
import urllib.parse
import urllib.request

import decky


class Plugin:
    def _settings_path(self):
        return os.path.join(decky.DECKY_PLUGIN_SETTINGS_DIR, "game-importer.json")

    def _load_settings(self):
        try:
            with open(self._settings_path(), "r", encoding="utf-8") as handle:
                return json.load(handle)
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return {"api_key": "", "scan_roots": []}

    def _save_settings(self, settings):
        os.makedirs(decky.DECKY_PLUGIN_SETTINGS_DIR, exist_ok=True)
        target = self._settings_path()
        temporary = target + ".tmp"
        with open(temporary, "w", encoding="utf-8") as handle:
            json.dump(settings, handle, ensure_ascii=False, indent=2)
        os.replace(temporary, target)

    async def _main(self):
        decky.logger.info("Game Importer loaded")

    async def _unload(self):
        decky.logger.info("Game Importer unloaded")

    async def get_settings(self):
        return self._load_settings()

    async def save_api_key(self, api_key=""):
        settings = self._load_settings()
        settings["api_key"] = api_key.strip()
        self._save_settings(settings)
        return True

    def _desktop_exec(self, path):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as handle:
                for line in handle:
                    if line.startswith("Exec="):
                        value = re.sub(r"\s+%[fFuUdDnNickvm]", "", line[5:].strip())
                        parts = shlex.split(value)
                        if parts and parts[0] == "env":
                            parts = [part for part in parts[1:] if "=" not in part]
                        if parts:
                            return parts[0], " ".join(shlex.quote(part) for part in parts[1:])
        except OSError:
            pass
        return path, ""

    def _candidate(self, path):
        name = os.path.basename(path)
        lower = name.lower()
        if lower.endswith(".desktop"):
            executable, launch_options = self._desktop_exec(path)
            display = os.path.splitext(name)[0].replace("-", " ").replace("_", " ")
            return {"name": display, "executable": executable, "start_dir": os.path.dirname(path), "launch_options": launch_options, "kind": "Desktop bejegyzés"}
        display = os.path.splitext(name)[0].replace("-", " ").replace("_", " ")
        kind = "Windows / Proton" if lower.endswith(".exe") else ("AppImage" if lower.endswith(".appimage") else "Linux program")
        return {"name": display, "executable": path, "start_dir": os.path.dirname(path), "launch_options": "", "kind": kind}

    def _is_candidate(self, path):
        lower = path.lower()
        if lower.endswith((".appimage", ".desktop", ".exe", ".sh")):
            return True
        try:
            mode = os.stat(path).st_mode
            return stat.S_ISREG(mode) and bool(mode & stat.S_IXUSR) and "." not in os.path.basename(path)
        except OSError:
            return False

    async def inspect_path(self, path=""):
        expanded = os.path.abspath(os.path.expanduser(path.strip()))
        if not os.path.isfile(expanded):
            raise ValueError("A megadott fájl nem található.")
        return self._candidate(expanded)

    async def scan_games(self):
        home = decky.DECKY_USER_HOME
        settings = self._load_settings()
        roots = settings.get("scan_roots") or [
            os.path.join(home, "Applications"),
            os.path.join(home, "Games"),
            os.path.join(home, ".local", "share", "applications"),
            "/run/media/deck",
        ]
        ignored = {"steamapps", ".steam", "compatdata", "shadercache", "node_modules", ".git"}
        found = []
        seen = set()
        for root in roots:
            root = os.path.expanduser(root)
            if not os.path.isdir(root):
                continue
            base_depth = root.rstrip(os.sep).count(os.sep)
            for current, directories, files in os.walk(root):
                depth = current.count(os.sep) - base_depth
                directories[:] = [d for d in directories if d.lower() not in ignored and not d.startswith(".")]
                if depth >= 4:
                    directories[:] = []
                for filename in files:
                    path = os.path.join(current, filename)
                    if path in seen or not self._is_candidate(path):
                        continue
                    seen.add(path)
                    found.append(self._candidate(path))
                    if len(found) >= 150:
                        return sorted(found, key=lambda item: item["name"].lower())
        return sorted(found, key=lambda item: item["name"].lower())

    def _sgdb_json(self, url, api_key):
        request = urllib.request.Request(url, headers={"Authorization": f"Bearer {api_key}", "User-Agent": "DeckyGameImporter/0.1"})
        with urllib.request.urlopen(request, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))

    async def search_artwork(self, game_name=""):
        api_key = self._load_settings().get("api_key", "")
        if not api_key:
            raise ValueError("Előbb add meg a SteamGridDB API-kulcsot.")
        query = urllib.parse.quote(game_name.strip())
        search = self._sgdb_json(f"https://www.steamgriddb.com/api/v2/search/autocomplete/{query}", api_key)
        games = search.get("data") or []
        if not games:
            return {"game": None, "cover": [], "wide": [], "hero": [], "logo": []}
        game = games[0]
        game_id = game["id"]
        endpoints = {
            "cover": f"grids/game/{game_id}?dimensions=600x900&types=static",
            "wide": f"grids/game/{game_id}?dimensions=920x430&types=static",
            "hero": f"heroes/game/{game_id}?types=static",
            "logo": f"logos/game/{game_id}?types=static",
        }
        result = {"game": {"id": game_id, "name": game.get("name", game_name)}}
        for key, endpoint in endpoints.items():
            payload = self._sgdb_json("https://www.steamgriddb.com/api/v2/" + endpoint, api_key)
            result[key] = [{"id": item.get("id"), "url": item.get("url"), "thumb": item.get("thumb") or item.get("url")} for item in (payload.get("data") or [])[:12]]
        return result

    async def download_artwork(self, url=""):
        if not url.startswith("https://"):
            raise ValueError("Érvénytelen artwork URL.")
        request = urllib.request.Request(url, headers={"User-Agent": "DeckyGameImporter/0.1"})
        with urllib.request.urlopen(request, timeout=30) as response:
            data = response.read(12 * 1024 * 1024)
            content_type = response.headers.get_content_type()
        image_format = "jpg" if content_type in ("image/jpeg", "image/jpg") else ("webp" if content_type == "image/webp" else "png")
        return {"data": base64.b64encode(data).decode("ascii"), "format": image_format}
