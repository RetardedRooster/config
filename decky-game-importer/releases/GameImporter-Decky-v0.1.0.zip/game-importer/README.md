# Game Importer for Decky

Kontrollerrel és érintéssel használható SteamOS plugin nem-Steam játékok hozzáadásához.

## Funkciók

- AppImage, `.desktop`, Linux program, shell script és Protonos `.exe` felismerése.
- Kézi elérési út megadása.
- SteamGridDB API-kulcs helyi mentése.
- Automatikus álló és széles borító, háttér és logó kiválasztás.
- Artwork előnézet és kézi lapozás a hozzáadás előtt.
- Azonnali shortcut- és artwork-beállítás a Steam belső kliens API-jával.
- Windows programokhoz Proton Experimental beállítása.
- Automatikus hozzáadás a `Telepített` gyűjteményhez, ha a Steam kliens gyűjtemény-API-ja elérhető.

## Telepítés

1. Telepítsd a Decky Loadert.
2. Kapcsold be a fejlesztői módot a Decky beállításaiban.
3. Telepítsd a kiadott ZIP-et fejlesztői plugin formájában, vagy másold a kibontott `game-importer` mappát a Decky plugins mappájába.
4. Indítsd újra a Decky Loadert.

## Megjegyzés

A Decky és a Steam kliens belső API-jai változhatnak. A plugin nem kapcsolódik a Valve Corporationhöz vagy a SteamGridDB-hez.
